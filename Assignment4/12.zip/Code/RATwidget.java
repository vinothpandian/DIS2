

/*
 * Really Awesome Widget
 * Extends the simple window acts as a abstract class for other UITK widgets
 *
 */


public abstract class RATwidget extends  SimpleWindow {

    public RATwidget(double doubleX, double doubleY, double doubleX1, double doubleY1) {
        super(doubleX, doubleY, doubleX1, doubleY1);
    }
}

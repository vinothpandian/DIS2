

/*
 * Really Awesome Mouse events
 *
 */
public enum RATmouseEvent {
    CLICKED,
    PRESSED,
    MOVED,
    DRAGGED,
    RELEASED
}
